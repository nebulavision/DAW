// Referencio los elementos que necesito para operar
const dateNumber = document.getElementById('dateNumber');
const dateText = document.getElementById('dateText');
const dateMonth = document.getElementById('dateMonth');
const dateYear = document.getElementById('dateYear');
const tasksContainer = document.getElementById('tasksContainer');
const form = document.getElementById('taskForm');
const orderButton = document.getElementById('orderButton');
const deleteButton = document.getElementById('deleteButton');

// Función para cambiar el estado de la tarea
// y actualizarlo en localStorage
const changeTaskState = event => {
    event.target.classList.toggle('done');

    const taskId = event.target.childNodes[1].value;
    const taskValue = event.target.textContent;
    const taskDone = event.target.classList.contains('done');

    editTaskFromLocalStorage(taskId, taskValue, taskDone);
}

// Funcionalidad extra
// Función para deshabilitar edición al perder el foco
// y guardar los cambios en localStorage
const disableEditing = event => {
    event.target.contentEditable = false;
    
    const taskId = event.target.childNodes[1].value;
    const taskValue = event.target.textContent;
    const taskDone = event.target.classList.contains('done');

    editTaskFromLocalStorage(taskId, taskValue, taskDone);
}

// Funcionalidad extra
// Función para habilitar edición de la tarea
const enableEditing = event => {
    const target = event.target;
    
    target.contentEditable = true;
    target.focus();
};

// Función para añadir una nueva tarea al localStorage
const addNewTask = event => {
    event.preventDefault();
    const { value } = event.target.taskText;
    if(!value) return;

    const taskId = addTaskToLocalStorage(value);
    addNewTaskToHTML(taskId, value, false);
    event.target.reset();
}

// Función para añadir una tarea a la vista
const addNewTaskToHTML = (taskId, taskValue, taskDone) => {
    const task = document.createElement('div');
    task.classList.add('task', 'roundBorder');
    if(taskDone) task.classList.add('done');
    task.textContent = taskValue;
    
    task.addEventListener('click', changeTaskState);

    //Funcionalidad extra
    // Añado el listener para el doble click
    task.addEventListener('dblclick', enableEditing);
    // Añado el listener para desactivar la edición al perder el foco
    task.addEventListener('blur', disableEditing);

    // Creo un input escondido para guardar el id de la tarea
    const idInput = document.createElement('input');
    idInput.setAttribute('type', 'text');
    idInput.setAttribute('hidden', true);
    idInput.setAttribute('value', taskId);
    task.appendChild(idInput);

    tasksContainer.prepend(task);
}

// Función para ordenar y renderizar las tareas
const renderOrderedTasks = () => {
    const done = [];
    const toDo = [];

    tasksContainer.childNodes.forEach(task => {
        task.classList.contains('done') ? done.push(task) : toDo.push(task)
    });
    const tasks = [...toDo, ...done];

    tasks.forEach(task => tasksContainer.appendChild(task)); 
}

// Función para eliminar todas las tareas
// Funcionalidad extra 
const deleteAllTasks = () => {
    tasksContainer.innerHTML = '';
    removeAllTasksFromLocalStorage();
}

// Función para mostrar la fecha
const setDate = () => {
    const date = new Date();

    dateNumber.textContent = date.toLocaleDateString('es', { day: 'numeric' });
    dateText.textContent = date.toLocaleDateString('es',  { weekday: 'long' });
    dateMonth.textContent = date.toLocaleDateString('es', { month: 'short' });
    dateYear.textContent = date.toLocaleDateString('es', { year: 'numeric'});
};

// Añado los listeners al formulario y a los botón de ordenar y eliminar
// Funcionalidad extra
const initEventListeners = () => {
    form.addEventListener('submit', addNewTask);
    orderButton.addEventListener('click', renderOrderedTasks);
    deleteButton.addEventListener('click', deleteAllTasks);
}

// Función para mostrar las tareas del localStorage
// Funcionalidad extra
const setTasks = () => {
    const tasks = getTasksFromLocalStorage();

    tasks.forEach(task => addNewTaskToHTML(task.id, task.task, task.done));
    renderOrderedTasks();
}

// Función para inicializar la app
const initApp = () => {
    setDate();
    initEventListeners();
    setTasks();
}

initApp();

// Funcionalidad extra
///////////////////////////////// localStorage functions ///////////////////////////////////////
// Función para obtener todas las tareas del localStorage
function getTasksFromLocalStorage(){
    return JSON.parse(localStorage.getItem('tasks')) || [];
}

// función para añadir una tarea al localStorage
function addTaskToLocalStorage(task){
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const newTaskId = tasks.length + 1;

    tasks.push({
        id: newTaskId,
        task: task,
        done: false
    });

    localStorage.setItem('tasks', JSON.stringify(tasks));

    return newTaskId;
}

// Función para editar una tarea en el localStorage
function editTaskFromLocalStorage(taskId, newTask, done){
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const taskIndex = tasks.findIndex(task => task.id == taskId);

    if(taskIndex !== -1){
        tasks[taskIndex] = {
            id: taskId,
            task: newTask,
            done: done
        };
    }

    localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Función para eliminar todas las tareas del localStorage
function removeAllTasksFromLocalStorage(){
    localStorage.removeItem('tasks');
}